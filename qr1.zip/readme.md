# PhoneGap Microspec Project

The purpose of this project is to code a cross platform application barcode and QR code reader.

To accomplish the task we have decided to use Phonegap, Cordova, and JQuery Mobile